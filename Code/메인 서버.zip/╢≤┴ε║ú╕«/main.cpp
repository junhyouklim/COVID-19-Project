#include "Common.h"
#include "Server.h"

int main(void)
{
    Server server;

    server.Server_Execute();

    return 0;
}